import javax.swing.*;

public class Main {


        public static void main(String[] args) {
            Ejecutable ex=new Ejecutable();
            ex.ejecutar();
        }
    }

