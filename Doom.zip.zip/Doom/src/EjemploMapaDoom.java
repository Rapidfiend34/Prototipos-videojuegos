import javax.swing.JFrame;

public class EjemploMapaDoom {
/*
    public static void main(String[] args) {
        MapaDoom mapa = new MapaDoom(10, 10); // Crear un mapa de 10x10 celdas
        mapa.agregarPared(0, 0, 10, true); // Agregar pared en la fila superior
        mapa.agregarPared(0, 0, 10, false); // Agregar pared en la columna izquierda
        mapa.agregarPared(9, 0, 10, true); // Agregar pared en la fila inferior
        mapa.agregarPared(0, 9, 10, false); // Agregar pared en la columna derecha
        mapa.agregarJugador(5, 5); // Agregar jugador en el centro del mapa

        PanelMapa panel = new PanelMapa(mapa); // Crear un panel para mostrar el mapa
        JFrame ventana = new JFrame("Ejemplo de mapa Doom"); // Crear una ventana para el panel
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 400);
        ventana.add(panel); // Agregar el panel a la ventana
        ventana.setVisible(true); // Mostrar la ventana
    }
}*/
}