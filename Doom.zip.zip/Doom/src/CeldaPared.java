public class CeldaPared extends Celda {
    public CeldaPared() {
        super(true);
    }


    @Override
    public char getCaracter() {
        return '#';
    }
}
