public class CeldaVacia  {
    private final char CARACTER = '.';

    public char getCaracter() {
        return CARACTER;
    }
}

