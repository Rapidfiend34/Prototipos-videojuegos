/*
 * Defineix un panel amb un cercle, un cuadrat i dues línies
 * Tot es pinta sobre un objecte Graphics2D
 */
package practica_final;

/**
 *
 * @author Aaron Fernandez Ramon
 *         Marc Gomez
 */

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

//Implementar el dibujo del rectangulo verde para fondo y marcador, a su vez implementara la parte de atras de las cartas
class CuadroD extends JPanel {

    private String fitxerImatge = "Cartes/card_back_blue.png";
    private BufferedImage img;
    public boolean ver;
    private Cartas aux;
    private int eX;
    private int eY;
    private int ANCHURA;
    private int ALTURA;
//Se dibujara dependiendo de sus parametros que determinaran las propiedades del dbujo
    public CuadroD(boolean a, int q, int b, int c, int w) {
        this.ANCHURA = c;
        this.ALTURA = w;
        this.eX = q;
        this.eY = b;
        this.ver = a;
        try {

            img = ImageIO.read(new File(fitxerImatge));

        } catch (IOException e) {
            System.out.println("Error");
        }

    }

    //Dependiendo de si cambia a la imagen de carta o de rectangulo de fondo variarán sus dimensiones
    @Override
    public void paintComponent(Graphics g) {
        if (!ver) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setBackground(new Color(42, 151, 42).darker());
            g2d.clearRect(eX, eY, ANCHURA, ALTURA);
        } else {
            g.drawImage(img, 0, 0, 100, 130, null);
        }
    }
}
