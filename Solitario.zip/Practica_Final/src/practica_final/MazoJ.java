/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_final;

import java.awt.Graphics;
import javax.swing.JPanel;
import static practica_final.Tablero.DIMJ;

/**
 *
 * @author Aaron Fernandez Ramon
 *         Marc Gomez
 */
//Creamos un objeto como mazo del usuario para tratar sus cartas e implementar el dibujo de su mazo en la interfaz
public class MazoJ extends JPanel {

    public Barajas total;
    public Cartas[] mazo = new Cartas[DIMJ];

    public MazoJ(Barajas b) {
        this.setBounds(0, 690, 1280, 200);
        this.total = b;
        this.mazo = total.Repartir(1);
        MostrarM();
    }
    //Establece las coordenadas de las cartas para dibujarlas en la posicion del tablero
    public void MostrarM() {
        int y = 50;
        int x = 20;
        for (int i = 0; i < DIMJ; i++) {
            mazo[i].ejex = x;
            mazo[i].ejey = y;
            x += 96;
        }
    }
    //Descarta la carta del mazo una vez haya sido utilizada
    public void eliminarC() {
        for (int i = 0; i < 13; i++) {
            mazo[i].visible = false;
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        for (int i = 0; i < DIMJ; i++) {
            //Dibujara la carta siempre que sea visible, es decir jugable
            if (mazo[i].visible) {
                mazo[i].paintComponent(g);
            }
        }
    }
}
