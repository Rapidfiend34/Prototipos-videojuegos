/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_final;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author Aaron Fernandez Ramon
 *         Marc Gomez
 */

//Creamos un objeto tablero para implementar las cartas en la interfaz 
public class Tablero extends JPanel {
    private Cartas aux;
    private boolean ver=true;
    private Cartas[][] t;
    private CuadroD[][] casillas;
    private Barajas B;
    private static int cont;
    public static final int DIMI = 4;
    public static final int DIMJ = 13;
    private static final int MAXIMO = 800;
    private final int ANCHURA = MAXIMO / DIMJ;
    private final int ALTURA=MAXIMO/DIMI;
    //construimos el tablero dependiendo de las cartas ofrecidas por la baraja
    public Tablero(Barajas aux){
       this.B=aux;
        this.setBounds(0, 10, 1280, 720);
        this.setLayout(null);
        Mostrar();      
        this.setBackground(Color.red);
    }
    //Dibujara las cartas junto el fondo de estas
    public void Mostrar(){
         t = new Cartas[DIMI][DIMJ];
         casillas=new CuadroD[DIMI][DIMJ];
         cont=0;
        int y = 170;
        int Cy=165;
        for (int i = 0; i < DIMI; i++) {
            int x = 20;
            int Cx=15;
        for (int j = 0; j < DIMJ; j++) {
            casillas[i][j]=new CuadroD(false,Cx,Cy,85,115);
               t[i][j]=B.cart[cont];
              
               t[i][j].ejex=x;
               t[i][j].ejey=y;
              
               
                x += ANCHURA+35;
                Cx+=ANCHURA+35;
                cont++;
            }
            y += ALTURA-75;
            Cy+=ALTURA-75;
        }
    }
       @Override
    public void paintComponent(Graphics g) {
        for (int i = 0; i < DIMI; i++) {
        for (int j = 0; j < DIMJ; j++) {
            casillas[i][j].paintComponent(g);
            //En el caso de que la carta no sea visible no la dibujara
           if(t[i][j].visible){
           t[i][j].paintComponent(g);
            }
        }}
    }
}
