package practica_final;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 *
 * @author Aaron Fernandez Ramon
 *         Marc Gomez
 */
//Creamos un objeto para analizar las propiedades de las cartas
public class Cartas {

    private BufferedImage img;
    public boolean visible;
    public int ejex;
    public int ejey;
    public int num;
    public categoria cat;
    private static String DireccionIm;
    public static ImageIcon imagen;

    public enum categoria {
        DIAMANTE, TREBOL, PICA, CORAZON
    };
    //Construira la carta correspondiente a sus parametros de entrada
    public Cartas(int numero, categoria Palo, int x, int y) {
        this.visible = true;
        this.ejex = x;
        this.ejey = y;
        this.num = numero;
        this.cat = Palo;
        switch (Palo) {
            case DIAMANTE:
                DireccionIm = "Cartes/" + Integer.toString(num);
                DireccionIm += "_of_diamonds.png";
                break;
            case TREBOL:
                DireccionIm = "Cartes/" + Integer.toString(num);
                DireccionIm += "_of_clubs.png";
                break;
            case PICA:
                DireccionIm = "Cartes/" + Integer.toString(num);
                DireccionIm += "_of_spades.png";
                break;
            case CORAZON:
                DireccionIm = "Cartes/" + Integer.toString(num);
                DireccionIm += "_of_hearts.png";
                break;
        }
        try {

            img = ImageIO.read(new File(DireccionIm));

        } catch (IOException e) {
            System.out.println("Error");
        }
    }

    public void paintComponent(Graphics g) {
        g.drawImage(img, ejex, ejey, 80, 110, null);

    }
}
