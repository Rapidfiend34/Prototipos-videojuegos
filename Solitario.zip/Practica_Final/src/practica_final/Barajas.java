package practica_final;

import java.util.Random;
import practica_final.Cartas.categoria;

/**
 *
 * @author Aaron Fernandez Ramon
 *         Marc Gomez
 */
//Creamos un objeto para gestionar la manipulacion de las cartas de la baraja
public class Barajas {

    private final int cantidad = 52;
    private final int cartasJS = 13;
    public Cartas[] cart;
    private int contador;
    private Tablero T;
    public Cartas c;
    //Construimos una baraja con cada una de las cartas ordenadas por numero y categoria
    public Barajas() {
        cart = new Cartas[cantidad];
        contador = 0;
        for (categoria aux : categoria.values()) {
            for (int i = 0; i < 13; i++) {
                cart[contador] = new Cartas(i + 1, aux, 0, 0);
                contador++;
            }
        }
    }
    //Sorteamos las cartas para asi tener la baraja completamente sorteada
    public void barajar() {
        for (int i = 0; i < cantidad; i++) {
            Cartas aux;
            int valor = 0;
            valor = new Random().nextInt(cantidad);
            aux = cart[valor];
            cart[valor] = cart[i];
            cart[i] = aux;

        }
    }
    //Modificamos las cartas de la baraja al estado no visible para que asi no sean visibles en el tablero
    public void AnularC() {
        contador = 0;
        for (categoria aux : categoria.values()) {
            for (int i = 0; i < 13; i++) {

                cart[contador].visible = false;
                contador++;
            }
        }
    }
    //Se repartira cada 13 cartas a cada uno de los jugadores
    public Cartas[] Repartir(int a) {
        Cartas[] ver = new Cartas[cartasJS];
        int ind = 0;
        switch (a) {
            case 1:
                ind = 0;
                for (int i = 0; i < 13; i++) {
                    ver[ind] = new Cartas(cart[i].num, cart[i].cat, cart[i].ejex, cart[i].ejey);
                    ind++;

                }
                break;
            case 2:
                ind = 0;
                for (int i = 13; i < 26; i++) {
                    ver[ind] = new Cartas(cart[i].num, cart[i].cat, cart[i].ejex, cart[i].ejey);
                    ind++;

                }
                break;
            case 3:
                ind = 0;
                for (int i = 26; i < 39; i++) {

                    ver[ind] = new Cartas(cart[i].num, cart[i].cat, cart[i].ejex, cart[i].ejey);
                    ind++;

                }
                break;
            case 4:
                ind = 0;
                for (int i = 39; i < 52; i++) {

                    ver[ind] = new Cartas(cart[i].num, cart[i].cat, cart[i].ejex, cart[i].ejey);
                    ind++;

                }
                break;
        }
        return ver;
    }
    //Comprobara si la carta seleccionada por los jugadores es valida para jugarla
    public boolean ComprobarCorrecta(int aux, Cartas a) {
        int indice;
        int posterior;
        for (int i = 0; i < 4; i++) {
            indice = aux + i * 13;
            if (aux < 6) {
                posterior = indice + 1;
            } else {
                posterior = indice - 1;
            }
            //En el caso de que se halle una carta con el mismo numero en la baraja y a su vez no sea visible en el tablero analizaremos
            //si la carta continua proxima al centro es visible en el tablero
            if ((cart[indice].num == a.num) && (!(cart[indice].visible))) {

                if ((cart[posterior].visible) && (a.num != 7)) {
                    cart[indice] = new Cartas(a.num, a.cat, a.ejex, a.ejey);;
                    return true;
                }
                if (a.num == 7) {
                    cart[indice] = new Cartas(a.num, a.cat, a.ejex, a.ejey);
                    return true;
                }
            }
        }

        return false;
    }
    //Verificar si la carta seleccionada por el usuario es de su mazo
    public boolean dentroCarta(int ind, int a, int b, Cartas[] aux) {

        if ((a >= aux[ind].ejex) && (a <= (aux[ind].ejex + 80)) && (b <= 850) && (b >= 740) && (aux[ind].visible)) {
            return true;
        }
        return false;
    }
}
