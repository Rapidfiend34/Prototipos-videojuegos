/*
 * To change this license header, choose License Headers in Project Properties.
 * To chang8 this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_final;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Aaron Fernandez Ramon
 *         Marc Gomez
 */

public class JPCentral extends JPanel {

    public Tablero game;
    private Inicio Ini;
    public CuadroD paint;
    public CuadroD Cuadro1J;
    public CuadroD Cuadro2J;
    public CuadroD Cuadro3J;
    public JLabel Cont1;
    public JLabel Cont2;
    public JLabel Cont3;
    public JLabel CartasJ;
    private Barajas b = new Barajas();
    //Creamos un componente como panel central para gestionar los contadores y todo tipo de interacciones de dibujos por raton
    public JPCentral(Inicio I) {
        this.Ini = I;
        this.setBackground(new Color(42, 151, 42));
        this.setSize(1280, 890);
        this.setLayout(null);
        IniComponents();
    }
    //Construimos sus componentes internos y propiedades
    public void IniComponents() {
        game = new Tablero(Ini.b);
        paint = new CuadroD(false, 0, 0, 85, 115);
        paint.setBounds(15, 740, 100, 130);
        Cuadro1J = new CuadroD(false, 0, 0, 150, 200);
        Cuadro1J.setBounds(315, 15, 100, 130);
        Cuadro2J = new CuadroD(false, 0, 0, 150, 200);
        Cuadro2J.setBounds(585, 15, 100, 130);
        Cuadro3J = new CuadroD(false, 0, 0, 150, 200);
        Cuadro3J.setBounds(855, 15, 100, 130);
        Cont1 = new JLabel("0");
        Cont1.setBounds(320, 15, 310, 45);
        Cont1.setFont(new Font("arial", Font.BOLD, 105));
        Cont1.setHorizontalAlignment(JLabel.CENTER);
        Cont1.setForeground(Color.WHITE);
        Cont1.setLayout(null);
        Cont2 = new JLabel("0");
        Cont2.setBounds(590, 15, 310, 45);
        Cont2.setFont(new Font("arial", Font.BOLD, 105));
        Cont2.setHorizontalAlignment(JLabel.CENTER);
        Cont2.setForeground(Color.WHITE);
        Cont2.setLayout(null);
        Cont3 = new JLabel("0");
        Cont3.setBounds(860, 15, 310, 45);
        Cont3.setFont(new Font("arial", Font.BOLD, 105));
        Cont3.setHorizontalAlignment(JLabel.CENTER);
        Cont3.setForeground(Color.WHITE);
        Cont3.setLayout(null);
        CartasJ = new JLabel("0");
        CartasJ.setBounds(10, 690, 100, 45);
        CartasJ.setFont(new Font("arial", Font.BOLD, 50));
        CartasJ.setHorizontalAlignment(JLabel.CENTER);
        CartasJ.setForeground(Color.WHITE);
        CartasJ.setLayout(null);
        game = new Tablero(Ini.b);
        Cuadro1J.add(Cont1);
        Cuadro2J.add(Cont2);
        Cuadro3J.add(Cont3);
        this.setLayout(null);
        this.add(CartasJ);
        this.add(paint);
        this.add(Cuadro1J);
        this.add(Cuadro2J);
        this.add(Cuadro3J);
        this.add(game);
    }
    //Restaura algunos de los valores iniciales del panel
    public void Default(Barajas aux) {
        this.remove(Ini.M);
        this.remove(game);
        game = new Tablero(aux);
        this.add(game);
        this.add(paint);
        this.Cuadro1J.ver = false;
        this.Cuadro2J.ver = false;
        this.Cuadro3J.ver = false;
        this.Cont1.setText("0");
        this.Cont2.setText("0");
        this.Cont3.setText("0");
        this.CartasJ.setText("0");
        this.repaint();
    }
    //Modifica los contadores y sus respectivos dibujos para iniciar el contador de la partida
    public void Empezar(){
         Cuadro1J.ver = true;
            Cuadro2J.ver = true;
            Cuadro3J.ver = true;
            remove(paint);
            CartasJ.setText("13");
            Cont1.setText("13");
            Cont2.setText("13");
            Cont3.setText("13");
    }
}
