/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1_taller_2;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author Fernandez Ramon,Aaron
 */
public class Panel extends JPanel{
    public static int x=1000;
    public static int y=1000;
    //Construimos el panel con la imagen como panel predeterminado
    public Panel(){
        this.setBounds(0,190-30,x, 700);
        this.setLayout(null);
        
    }
            
   
   
}
